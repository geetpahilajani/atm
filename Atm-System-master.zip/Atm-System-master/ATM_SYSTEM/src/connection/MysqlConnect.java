package connection;









public class MysqlConnect{ 
    public static void main(String args[]){
         //new ATM_SYSTEM().setVisible(true);
         }
}
