# Atm-System
In this Project I have demonstrate Working Of Atm.All Transactions like Deposit,Withdraw,Balance transfer,Change pin,Check Balance and One ADMIN PANEL to ADD Customers and To View How Many Customers Exists.This is v1 I hope You Will Like It.THANK YOU.


***************NOTE****************
To use this project use have to create database in MySql to store and retrieve data.

like this:

DATABASE name:atm


table name : details


mysql root name:root


pass:root(in my case u can give ur own)


connection name:localhost


port:3306


table's coloumn name:
id,username,password,email,address,mob_no,balance

